import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme.dart';
import '../../models/note.dart';
import '../../models/rule.dart';
import '../../providers/notes_provider.dart';
import '../../providers/rules_provider.dart';
import '../../widgets/common/app_widgets.dart';
import '../../widgets/common/christian_art.dart';
import '../rules/rule_widgets.dart';

/// Combined Notes + Universal Rules screen accessed from the bottom nav.
/// Uses a TabBar to switch between the two sections so users don't need
/// two separate nav items.
class NotesRulesScreen extends ConsumerStatefulWidget {
  const NotesRulesScreen({super.key});

  @override
  ConsumerState<NotesRulesScreen> createState() => _NotesRulesScreenState();
}

class _NotesRulesScreenState extends ConsumerState<NotesRulesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  // — Notes state —
  bool _isGridView = false;
  String _notesQuery = '';
  String _notesFilter = 'All'; // All | Pinned | Favorites

  // — Rules state —
  String _rulesCat = 'All';
  String _rulesQuery = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.navy,
      appBar: AppBar(
        backgroundColor: AppTheme.navySurface,
        elevation: 0,
        title: AnimatedBuilder(
          animation: _tabController,
          builder: (_, __) {
            final isNotes = _tabController.index == 0;
            return Row(
              children: [
                Text(isNotes ? '📝 ' : '📜 ', style: const TextStyle(fontSize: 20)),
                Text(
                  isNotes ? 'Spiritual Notes' : 'My Rules',
                  style: TextStyle(
                    fontFamily: 'Lora',
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ],
            );
          },
        ),
        actions: [
          AnimatedBuilder(
            animation: _tabController,
            builder: (_, __) {
              if (_tabController.index == 0) {
                return Row(
                  children: [
                    IconButton(
                      icon: Icon(_isGridView ? Icons.view_list : Icons.grid_view,
                          color: AppTheme.textPrimary),
                      onPressed: () => setState(() => _isGridView = !_isGridView),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add, color: AppTheme.gold),
                      onPressed: () => context.push('/notes/new'),
                    ),
                  ],
                );
              }
              return IconButton(
                icon: const Icon(Icons.add, color: AppTheme.gold),
                onPressed: () => context.push('/rules/new'),
              );
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.gold,
          indicatorWeight: 3,
          labelColor: AppTheme.gold,
          unselectedLabelColor: AppTheme.textMuted,
          labelStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.bold, fontSize: 13),
          unselectedLabelStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w400, fontSize: 13),
          tabs: const [
            Tab(text: 'Notes'),
            Tab(text: 'Rules'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildNotesTab(),
          _buildRulesTab(),
        ],
      ),
    );
  }

  // ── NOTES TAB ─────────────────────────────────────────────────────────────

  Widget _buildNotesTab() {
    final notesAsync = ref.watch(notesProvider);

    return RefreshIndicator(
      onRefresh: () async {
        ref.read(notesProvider.notifier).refresh();
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _notesSummary(notesAsync.valueOrNull),
            const SizedBox(height: 14),
            _buildSearchBar(
              hint: 'Search notes...',
              onChanged: (v) => setState(() => _notesQuery = v.toLowerCase()),
            ),
            const SizedBox(height: 12),
            _buildNoteFilters(),
            const SizedBox(height: 16),
            notesAsync.when(
              loading: () => const LoadingShimmer(height: 200),
              error: (e, _) => ErrorView(message: friendlyError(e), onRetry: () => ref.read(notesProvider.notifier).refresh()),
              data: (notes) {
                final filtered = notes.where((n) {
                  final matchesQuery = _notesQuery.isEmpty ||
                      n.title.toLowerCase().contains(_notesQuery) ||
                      n.content.toLowerCase().contains(_notesQuery) ||
                      n.preview.toLowerCase().contains(_notesQuery) ||
                      n.topicNames.any((t) => t.toLowerCase().contains(_notesQuery));
                  final matchesFilter = _notesFilter == 'All' ||
                      (_notesFilter == 'Pinned' && n.isPinned) ||
                      (_notesFilter == 'Favorites' && n.isFavorite);
                  return matchesQuery && matchesFilter;
                }).toList();
                // Pinned notes first, otherwise keep the server's order (newest first).
                filtered.sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0));

                if (filtered.isEmpty) {
                  final none = notes.isEmpty;
                  return EmptyView(
                    title: none ? 'Your notes will live here' : 'No matching notes',
                    subtitle: none
                        ? 'Write down what God is teaching you: sermon thoughts, prayers, verses that spoke to you.'
                        : 'Try a different search or filter',
                    icon: Icons.edit_note,
                    action: none
                        ? ElevatedButton.icon(
                            onPressed: () => context.push('/notes/new'),
                            icon: const Icon(Icons.add),
                            label: const Text('Write your first note'),
                            style: ElevatedButton.styleFrom(minimumSize: const Size(220, 48)),
                          )
                        : null,
                  );
                }
                return _isGridView
                    ? _buildGridNotes(filtered)
                    : _buildListNotes(filtered);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoteFilters() {
    return SizedBox(
      height: 38,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          for (final f in const ['All', 'Pinned', 'Favorites'])
            GestureDetector(
              onTap: () => setState(() => _notesFilter = f),
              child: _pill(f, _notesFilter == f),
            ),
        ],
      ),
    );
  }

  Widget _summaryCard({required IconData icon, required Color color, required String title, required String sub, double? progress}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [color.withValues(alpha: 0.16), AppTheme.navySurface], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontFamily: 'Lora', fontSize: 17, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
            const SizedBox(height: 2),
            Text(sub, style: TextStyle(fontFamily: 'Inter', fontSize: 12, color: AppTheme.textSecondary)),
            if (progress != null) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(value: progress, minHeight: 6, color: color, backgroundColor: color.withValues(alpha: 0.15)),
              ),
            ],
          ]),
        ),
      ]),
    );
  }

  Widget _notesSummary(List<Note>? notes) {
    final n = notes?.length ?? 0;
    final pinned = notes?.where((x) => x.isPinned).length ?? 0;
    return _summaryCard(
      icon: Icons.edit_note,
      color: AppTheme.softBlue,
      title: n == 0 ? 'Your notes' : '$n note${n == 1 ? '' : 's'}',
      sub: n == 0 ? 'Write down what God is teaching you.' : '${pinned == 0 ? 'None' : pinned} pinned',
    );
  }

  Widget _rulesSummary(List<Rule>? rules) {
    final n = rules?.length ?? 0;
    return SizedBox(
      height: 140,
      child: Stack(fit: StackFit.expand, children: [
        const ArtImage(fallbackScene: 'sunrise', animate: true, radius: 22),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x00000000), Color(0xAA000000)],
            ),
          ),
        ),
        Positioned(
          left: 18,
          right: 18,
          bottom: 14,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(n == 0 ? 'Your rules' : '$n rule${n == 1 ? '' : 's'}',
                style: const TextStyle(fontFamily: 'Lora', fontSize: 21, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 2),
            Text(
              n == 0 ? 'Add the rules you want to live by.' : 'They take turns on your Home page, a new one every 10 minutes.',
              style: const TextStyle(fontSize: 12.5, color: Colors.white, height: 1.3),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildListNotes(List<Note> notes) {
    return Column(
      children: [for (var i = 0; i < notes.length; i++) _buildNoteCard(notes[i], i + 1)],
    );
  }

  Widget _buildGridNotes(List<Note> notes) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.78,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: notes.length,
      itemBuilder: (_, i) => _buildNoteCard(notes[i], i + 1, compact: true),
    );
  }

  /// "Just now", "5 min ago", "Yesterday", "3 days ago", or a short date for older notes.
  String _relativeDate(String iso) {
    final d = DateTime.tryParse(iso)?.toLocal();
    if (d == null) return '';
    final diff = DateTime.now().difference(d);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
    if (diff.inHours < 24) return '${diff.inHours} h ago';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays} days ago';
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${d.day} ${m[d.month - 1]}${d.year == DateTime.now().year ? '' : ' ${d.year}'}';
  }

  Widget _noteChip(String label, Color color, {IconData? icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(8)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 11, color: color), const SizedBox(width: 3)],
        Flexible(
          child: Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontFamily: 'Inter', fontSize: 10.5, fontWeight: FontWeight.w700, color: color)),
        ),
      ]),
    );
  }

  Widget _buildNoteCard(Note note, int number, {bool compact = false}) {
    final topic = note.topicsList.isNotEmpty ? note.topicsList.first : null;
    final accent = note.isPinned ? AppTheme.gold : ruleColorFromHex(topic?.color, fallback: AppTheme.softBlue);
    final preview = note.content.trim().isNotEmpty ? note.content.trim() : note.preview.trim();
    final category = topic?.name ?? note.folderName;
    return GestureDetector(
      onTap: () => context.push('/notes/${note.id}'),
      child: Container(
        margin: EdgeInsets.only(bottom: compact ? 0 : 12),
        decoration: BoxDecoration(
          color: AppTheme.navySurface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.navyOutline),
          boxShadow: [BoxShadow(color: AppTheme.inkNavy.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        clipBehavior: Clip.antiAlias,
        child: IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Container(width: 5, color: accent),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Text(
                        note.title.isEmpty ? 'Untitled note' : note.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: 'Lora', fontSize: 16.5, fontWeight: FontWeight.bold, height: 1.25, color: AppTheme.textPrimary),
                      ),
                    ),
                    if (note.isPinned)
                      Padding(
                        padding: const EdgeInsets.only(left: 6, top: 2),
                        child: Icon(Icons.push_pin, color: AppTheme.gold, size: 15),
                      ),
                    if (note.isFavorite)
                      Padding(
                        padding: const EdgeInsets.only(left: 4, top: 2),
                        child: Icon(Icons.favorite, color: AppTheme.accentPink, size: 15),
                      ),
                  ]),
                  if (preview.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      preview,
                      maxLines: compact ? 4 : 3,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontFamily: 'Inter', fontSize: 13, color: AppTheme.textSecondary, height: 1.5),
                    ),
                  ],
                  const SizedBox(height: 10),
                  Row(children: [
                    if (category != null && category.isNotEmpty)
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: _noteChip(category, accent, icon: topic != null ? Icons.sell_outlined : Icons.folder_outlined),
                        ),
                      ),
                    if (note.bibleReferences.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: _noteChip('${note.bibleReferences.length}', AppTheme.goldAccent, icon: Icons.menu_book_rounded),
                      ),
                    const Spacer(),
                    Text(_relativeDate(note.updatedAt),
                        style: TextStyle(fontFamily: 'Inter', fontSize: 11, color: AppTheme.textMuted)),
                  ]),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ── RULES TAB ─────────────────────────────────────────────────────────────

  Widget _buildRulesTab() {
    final rulesAsync = ref.watch(rulesProvider);
    final categoriesAsync = ref.watch(ruleCategoriesProvider);

    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(rulesProvider);
        ref.invalidate(ruleCategoriesProvider);
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rulesSummary(rulesAsync.valueOrNull),
            const SizedBox(height: 14),
            _buildSearchBar(
              hint: 'Search rules...',
              onChanged: (v) => setState(() => _rulesQuery = v.toLowerCase()),
            ),
            const SizedBox(height: 16),
            _buildCategoryPills(categoriesAsync),
            const SizedBox(height: 20),
            rulesAsync.when(
              loading: () => const LoadingShimmer(height: 200),
              error: (e, _) => ErrorView(message: friendlyError(e)),
              data: (rules) {
                final filtered = rules.where((r) {
                  final matchesCat =
                      _rulesCat == 'All' || (r.categoryName ?? '') == _rulesCat;
                  final matchesQuery = _rulesQuery.isEmpty ||
                      r.title.toLowerCase().contains(_rulesQuery) ||
                      (r.description ?? '').toLowerCase().contains(_rulesQuery);
                  return matchesCat && matchesQuery;
                }).toList();
                if (filtered.isEmpty) {
                  return EmptyView(
                    title: rules.isEmpty ? 'No rules yet' : 'No matching rules',
                    subtitle: rules.isEmpty
                        ? 'Tap + to add your first rule'
                        : 'Try a different search or category',
                    icon: Icons.rule,
                  );
                }
                return Column(
                  children: [
                    for (var i = 0; i < filtered.length; i++) _buildRuleItem(filtered[i], i + 1),
                    const SizedBox(height: 4),
                    TextButton.icon(
                      onPressed: () => context.push('/rules/new'),
                      icon: const Icon(Icons.add),
                      label: const Text('Add a rule'),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryPills(AsyncValue<List<RuleCategory>> categoriesAsync) {
    return categoriesAsync.when(
      loading: () => const SizedBox(height: 38),
      error: (_, __) => const SizedBox.shrink(),
      data: (cats) => SizedBox(
        height: 38,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: cats.length + 1,
          itemBuilder: (_, i) {
            final label = i == 0 ? 'All' : cats[i - 1].name;
            final isSelected = _rulesCat == label;
            return GestureDetector(
              onTap: () => setState(() => _rulesCat = label),
              child: _pill(label, isSelected),
            );
          },
        ),
      ),
    );
  }

  Widget _buildRuleItem(Rule rule, int number) {
    final desc = (rule.description ?? '').trim();
    final isLong = desc.length > 140 || '\n'.allMatches(desc).length >= 3;
    return GestureDetector(
      onTap: () => context.push('/rules/${rule.id}'),
      child: Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppTheme.navySurface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.navyOutline),
        boxShadow: [BoxShadow(color: AppTheme.inkNavy.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SizedBox(
          height: 110,
          child: Stack(fit: StackFit.expand, children: [
            KeyedArt(artKey: 'rule_${rule.id}', fallbackScene: sceneForId(rule.id), radius: 0),
            Positioned(
              left: 12,
              top: 12,
              child: Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.45), borderRadius: BorderRadius.circular(11)),
                child: Text(number.toString().padLeft(2, '0'),
                    style: const TextStyle(fontFamily: 'Lora', fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
            Positioned(
              right: 4,
              top: 4,
              child: IconButton(
                tooltip: 'More',
                icon: const Icon(Icons.more_vert, color: Colors.white, size: 20),
                onPressed: () => _showRuleActions(rule),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(rule.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontFamily: 'Lora', fontSize: 17, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
            if (desc.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(desc,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontFamily: 'Inter', fontSize: 13, color: AppTheme.textSecondary, height: 1.45)),
              if (isLong)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Read more',
                      style: TextStyle(
                          fontFamily: 'Inter', fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.goldAccent)),
                ),
            ],
            if (rule.scriptures.isNotEmpty) ...[
              const SizedBox(height: 10),
              ScriptureQuote(scripture: rule.scriptures.first, compact: true),
            ],
            if (rule.categoryName != null || rule.isPinned) ...[
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                if (rule.categoryName != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.gold.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(rule.categoryName!,
                        style: TextStyle(
                            fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.bold, color: AppTheme.goldAccent)),
                  ),
                if (rule.isPinned) const Icon(Icons.push_pin, color: AppTheme.gold, size: 12),
              ]),
            ],
          ]),
        ),
      ]),
    ),
    );
  }

  Future<void> _changeRulePicture(Rule rule) async {
    final key = 'rule_${rule.id}';
    final choice = await showArtPicker(context, current: ArtStore.instance.of(key), fallbackScene: sceneForId(rule.id));
    if (choice != null) await ArtStore.instance.set(key, choice);
  }

  void _showRuleActions(Rule rule) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.navySurface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined, color: AppTheme.gold),
              title: Text('Edit Rule', style: TextStyle(color: AppTheme.textPrimary)),
              onTap: () {
                Navigator.pop(context);
                context.push('/rules/${rule.id}/edit');
              },
            ),
            ListTile(
              leading: const Icon(Icons.image_outlined, color: AppTheme.gold),
              title: Text('Change picture', style: TextStyle(color: AppTheme.textPrimary)),
              onTap: () {
                Navigator.pop(context);
                _changeRulePicture(rule);
              },
            ),
            ListTile(
              leading: Icon(
                rule.isFavorite ? Icons.favorite : Icons.favorite_border,
                color: AppTheme.accentPink,
              ),
              title: Text(rule.isFavorite ? 'Remove Favorite' : 'Mark Favorite',
                  style: TextStyle(color: AppTheme.textPrimary)),
              onTap: () {
                ref.read(rulesProvider.notifier).toggleFavorite(rule.id);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Delete Rule', style: TextStyle(color: Colors.red)),
              onTap: () {
                ref.read(rulesProvider.notifier).delete(rule.id);
                ref.invalidate(todayRulesProvider);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ── Shared Helpers ─────────────────────────────────────────────────────────

  Widget _buildSearchBar({required String hint, required ValueChanged<String> onChanged}) {
    return TextField(
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: AppTheme.textMuted, fontSize: 14),
        prefixIcon: Icon(Icons.search, color: AppTheme.textMuted),
        fillColor: AppTheme.navySurface,
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppTheme.navyOutline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppTheme.navyOutline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.gold, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
      ),
    );
  }

  Widget _pill(String label, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isSelected ? AppTheme.gold : AppTheme.navySurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSelected ? AppTheme.gold : AppTheme.navyOutline,
        ),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontFamily: 'Inter',
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: isSelected ? AppTheme.inkNavy : AppTheme.textPrimary,
        ),
      ),
    );
  }
}
