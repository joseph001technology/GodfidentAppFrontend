import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/auth_provider.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/auth/forgot_password_screen.dart';
import '../screens/auth/verify_email_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/bible/bible_screen.dart';
import '../screens/bible/chapter_screen.dart';
import '../screens/bible/verse_detail_screen.dart';
import '../screens/bible/search_screen.dart';
import '../screens/bible/bible_library_screen.dart';
import '../screens/devotionals/devotional_detail_screen.dart';
import '../screens/devotionals/devotional_list_screen.dart';
import '../screens/reading_plans/plans_screen.dart';
import '../screens/reading_plans/my_plans_screen.dart';
import '../screens/reading_plans/plan_day_screen.dart';
import '../screens/prayer/prayer_list_screen.dart';
import '../screens/prayer/prayer_form_screen.dart';
import '../screens/prayer/prayer_detail_screen.dart';
import '../screens/prayer/prayer_stats_screen.dart';
import '../screens/analytics/dashboard_screen.dart';
import '../screens/search/global_search_screen.dart';
import '../screens/notes/notes_rules_screen.dart';
import '../screens/notes/note_editor_screen.dart';
import '../screens/notes/note_detail_screen.dart';
import '../screens/rules/rule_editor_screen.dart';
import '../screens/rules/rule_detail_screen.dart';
import '../screens/reminders/reminders_screen.dart';
import '../screens/reminders/reminder_editor_screen.dart';
import '../screens/notifications/notifications_screen.dart';
import '../screens/focus/focus_screen.dart';
import '../screens/focus/app_restrictions_screen.dart';
import '../screens/focus/schedule_editor_screen.dart';
import '../screens/focus/website_protection_screen.dart';
import '../screens/focus/permissions_screen.dart';
import '../screens/music/music_screen.dart';
import '../screens/settings/edit_profile_screen.dart';
import '../screens/settings/profile_screen.dart';
import '../screens/settings/change_password_screen.dart';
import '../screens/settings/notification_settings_screen.dart';
import '../screens/achievements/achievements_screen.dart';
import '../widgets/common/shell_scaffold.dart';
import '../screens/reminders/fasting_checkin_screen.dart';
import 'package:flutter/material.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);
  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      final isAuthed = authState.value == true;
      final isAuthRoute = state.matchedLocation.startsWith('/login') ||
          state.matchedLocation.startsWith('/register') ||
          state.matchedLocation.startsWith('/forgot') ||
          state.matchedLocation.startsWith('/verify');
      if (!isAuthed && !isAuthRoute) return '/login';
      if (isAuthed && isAuthRoute) return '/home';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),
      GoRoute(path: '/forgot-password', builder: (_, __) => const ForgotPasswordScreen()),
      GoRoute(path: '/verify-email', builder: (_, __) => const VerifyEmailScreen()),

      ShellRoute(
        builder: (context, state, child) => ShellScaffold(child: child),
        routes: [
          GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
          GoRoute(path: '/music', builder: (_, __) => const MusicScreen()),
          GoRoute(
            path: '/bible',
            builder: (_, state) => BibleScreen(browse: state.uri.queryParameters['browse'] == '1'),
            routes: [
              GoRoute(
                path: 'chapter',
                builder: (_, state) => ChapterScreen(
                  book: state.uri.queryParameters['book']!,
                  chapter: int.parse(state.uri.queryParameters['chapter']!),
                  translation: state.uri.queryParameters['translation'] ?? 'KJV',
                  focusVerse: int.tryParse(state.uri.queryParameters['verse'] ?? ''),
                  resume: state.uri.queryParameters['resume'] == '1',
                ),
              ),
              GoRoute(
                path: 'library',
                builder: (_, state) => BibleLibraryScreen(
                  initialTab: int.tryParse(state.uri.queryParameters['tab'] ?? '') ?? 0,
                ),
              ),
              GoRoute(
                path: 'verse',
                builder: (_, state) => VerseDetailScreen(
                  book: state.uri.queryParameters['book']!,
                  chapter: int.parse(state.uri.queryParameters['chapter']!),
                  verse: int.parse(state.uri.queryParameters['verse']!),
                  translation: state.uri.queryParameters['translation'] ?? 'KJV',
                ),
              ),
              GoRoute(path: 'search', builder: (_, __) => const SearchScreen()),
            ],
          ),
          GoRoute(
            path: '/focus',
            builder: (_, state) => FocusScreen(
              key: ValueKey('focus-${state.uri.queryParameters['start'] ?? ''}'),
              startScheduleId: int.tryParse(state.uri.queryParameters['start'] ?? ''),
            ),
            routes: [
              GoRoute(path: 'schedule/new', builder: (_, __) => const ScheduleEditorScreen()),
              GoRoute(
                path: 'schedule/:id',
                builder: (_, state) => ScheduleEditorScreen(scheduleId: int.tryParse(state.pathParameters['id'] ?? '')),
              ),
              GoRoute(path: 'apps', builder: (_, __) => const AppRestrictionsScreen()),
              GoRoute(path: 'websites', builder: (_, __) => const WebsiteProtectionScreen()),
              GoRoute(path: 'permissions', builder: (_, __) => const PermissionsScreen()),
            ],
          ),
          GoRoute(path: '/progress', redirect: (_, __) => '/analytics'),

          // Prayer routes
          GoRoute(
            path: '/prayer',
            builder: (_, __) => const PrayerListScreen(),
            routes: [
              GoRoute(path: 'new', builder: (_, __) => const PrayerFormScreen()),
              GoRoute(
                path: 'focus',
                redirect: (_, __) => '/focus', // one Focus for everything: prayer + Bible time
              ),
              GoRoute(path: 'stats', builder: (_, __) => const PrayerStatsScreen()),
              GoRoute(
                path: ':id',
                builder: (_, state) => PrayerDetailScreen(id: int.parse(state.pathParameters['id']!)),
                routes: [
                  GoRoute(
                    path: 'edit',
                    builder: (_, state) => PrayerFormScreen(prayerId: int.parse(state.pathParameters['id']!)),
                  ),
                ],
              ),
            ],
          ),

          // Notes + Rules combined tab screen
          GoRoute(
            path: '/notes',
            builder: (_, __) => const NotesRulesScreen(),
            routes: [
              GoRoute(
                path: 'new',
                builder: (_, state) => NoteEditorScreen(
                  topicId: state.uri.queryParameters['topic'],
                ),
              ),
              GoRoute(
                path: ':id',
                builder: (_, state) => NoteDetailScreen(
                  noteId: int.parse(state.pathParameters['id']!),
                ),
                routes: [
                  GoRoute(
                    path: 'edit',
                    builder: (_, state) => NoteEditorScreen(
                      noteId: state.pathParameters['id'],
                    ),
                  ),
                ],
              ),
            ],
          ),

          // Rules editor routes (accessed from Notes tab or deep links)
          GoRoute(
            path: '/rules',
            builder: (_, __) => const NotesRulesScreen(),
            routes: [
              GoRoute(
                path: 'new',
                builder: (_, __) => const RuleEditorScreen(),
              ),
              GoRoute(
                path: ':id',
                routes: [
                  GoRoute(
                    path: 'edit',
                    builder: (_, state) => RuleEditorScreen(
                      ruleId: state.pathParameters['id'],
                    ),
                  ),
                ],
                builder: (_, state) => RuleDetailScreen(
                  ruleId: int.tryParse(state.pathParameters['id'] ?? '') ?? 0,
                ),
              ),
            ],
          ),

          // Notification settings
          GoRoute(
            path: '/notification-settings',
            builder: (_, __) => const NotificationSettingsScreen(),
          ),

          GoRoute(
            path: '/fasting-checkin',
            builder: (_, state) => FastingCheckinScreen(
              reminderId: int.tryParse(state.uri.queryParameters['id'] ?? '') ?? 0,
              title: state.uri.queryParameters['title'] ?? 'Fasting',
            ),
          ),

          // Reminders routes
          GoRoute(
            path: '/reminders',
            builder: (_, __) => const RemindersScreen(),
            routes: [
              GoRoute(
                path: 'new',
                builder: (_, __) => const ReminderEditorScreen(),
              ),
              GoRoute(
                path: ':id',
                builder: (_, state) => ReminderEditorScreen(
                  reminderId: state.pathParameters['id'],
                ),
              ),
            ],
          ),

          // Analytics routes
          GoRoute(
            path: '/analytics',
            builder: (_, __) => const DashboardScreen(),
          ),

          // Profile & Settings routes
          GoRoute(
            path: '/profile',
            builder: (_, __) => const ProfileScreen(),
            routes: [
              GoRoute(path: 'edit', builder: (_, __) => const EditProfileScreen()),
              GoRoute(path: 'change-password', builder: (_, __) => const ChangePasswordScreen()),
            ],
          ),
          GoRoute(path: '/settings', redirect: (_, __) => '/profile'),
          GoRoute(path: '/settings/notifications', redirect: (_, __) => '/notification-settings'),

          // Global Search route
          GoRoute(
            path: '/global-search',
            builder: (_, __) => const GlobalSearchScreen(),
          ),

          // More routes
          GoRoute(
            path: '/more',
            builder: (_, __) => const DevotionalListScreen(),
            routes: [
              GoRoute(path: 'devotionals', builder: (_, __) => const DevotionalListScreen()),
              GoRoute(
                path: 'devotionals/:id',
                builder: (_, state) => DevotionalDetailScreen(id: int.parse(state.pathParameters['id']!)),
              ),
              GoRoute(path: 'devotionals/saved', builder: (_, __) => const SavedDevotionalsScreen()),
              GoRoute(path: 'plans', builder: (_, __) => const PlansScreen()),
              GoRoute(path: 'my-plans', builder: (_, __) => const MyPlansScreen()),
              GoRoute(
                path: 'plans/:id/day',
                builder: (_, state) => PlanDayScreen(planId: int.parse(state.pathParameters['id']!)),
              ),
              GoRoute(path: 'notifications', builder: (_, __) => const NotificationsScreen()),
              GoRoute(path: 'achievements', builder: (_, __) => const AchievementsScreen()),
            ],
          ),
        ],
      ),
    ],
  );
});