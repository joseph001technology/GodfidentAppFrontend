package com.example.godfident_flutter

import android.app.Notification
import android.app.NotificationChannel
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Real website blocking.
 *
 * Establishes a local VPN whose ONLY route is a fake DNS server address.
 * Every DNS lookup the phone makes (Chrome, Firefox, any app) is therefore
 * delivered to this service. A lookup for a blocked domain (or any of its
 * subdomains) is answered with NXDOMAIN, so the site cannot load; every
 * other lookup is forwarded untouched to a real resolver. No web traffic
 * is read or stored — only the host name inside DNS queries is inspected,
 * and nothing leaves the device.
 *
 * Known limits (also shown to the user in the app):
 *  - Browsers using their own DNS-over-HTTPS ("Secure DNS") or Android
 *    "Private DNS" in strict mode bypass this; the app warns about the
 *    latter and the user must disable Secure DNS in the browser.
 *  - The user can still switch the VPN off in Android settings; the app
 *    then reports protection as INACTIVE (see [onRevoke]).
 */
class WebsiteBlockVpnService : VpnService() {

    companion object {
        const val PREFS = "godfident_website_prefs"
        const val KEY_DOMAINS = "blocked_domains"
        const val KEY_KEYWORDS = "blocked_keywords"
        const val KEY_ACTIVE = "protection_active"
        const val KEY_BLOCKED_COUNT = "blocked_lookup_count"
        const val ACTION_STOP = "com.example.godfident_flutter.STOP_WEB_PROTECTION"

        private const val CHANNEL_ID = "website_protection"
        private const val NOTIFICATION_ID = 4202
        private const val VPN_ADDRESS = "10.99.0.1"
        private const val FAKE_DNS = "10.99.0.2"
        private val UPSTREAM_DNS = arrayOf("8.8.8.8", "1.1.1.1", "9.9.9.9")

        @Volatile
        var isRunning: Boolean = false
            private set

        // Live diagnostics shown in the app so "is it even receiving lookups?" is answerable.
        @Volatile var totalQueries: Int = 0
        @Volatile var lastHost: String = ""
        @Volatile var lastError: String = ""

        private const val WATCHDOG_REQUEST = 4203
        private const val WATCHDOG_INTERVAL_MS = 15 * 60 * 1000L

        /**
         * Keeps protection alive while the app is closed: every 15 minutes
         * (and after the task is swiped away) [BootReceiver] checks whether
         * protection is wanted but not running, and starts it again.
         */
        fun scheduleWatchdog(ctx: Context) {
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pi = PendingIntent.getBroadcast(
                    ctx, WATCHDOG_REQUEST,
                    Intent(ctx, BootReceiver::class.java).setAction(BootReceiver.ACTION_WATCHDOG),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.setInexactRepeating(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + WATCHDOG_INTERVAL_MS,
                    WATCHDOG_INTERVAL_MS, pi
                )
            } catch (_: Exception) {
            }
        }

        fun cancelWatchdog(ctx: Context) {
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pi = PendingIntent.getBroadcast(
                    ctx, WATCHDOG_REQUEST,
                    Intent(ctx, BootReceiver::class.java).setAction(BootReceiver.ACTION_WATCHDOG),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.cancel(pi)
            } catch (_: Exception) {
            }
        }

        /**
         * Sites that load from several domains. Blocking the main name alone lets the
         * rest of the site (or its app) keep working, which is why some sites seemed
         * "half blocked". Blocking any name in a group blocks the whole group.
         */
        private val SITE_GROUPS: List<Set<String>> = listOf(
            setOf("tiktok.com", "tiktokv.com", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "ttwstatic.com", "byteoversea.com", "ibytedtos.com", "musical.ly"),
            setOf("youtube.com", "youtu.be", "ytimg.com", "youtube-nocookie.com", "googlevideo.com", "youtubekids.com", "yt.be"),
            setOf("instagram.com", "cdninstagram.com", "instagr.am", "ig.me"),
            setOf("facebook.com", "fb.com", "fb.me", "fbcdn.net", "facebook.net", "fbsbx.com", "messenger.com", "m.me"),
            setOf("twitter.com", "x.com", "t.co", "twimg.com"),
            setOf("snapchat.com", "sc-cdn.net", "snap-dev.net", "snapkit.com"),
            setOf("reddit.com", "redd.it", "redditmedia.com", "redditstatic.com"),
            setOf("netflix.com", "nflxvideo.net", "nflximg.net", "nflxext.com", "nflxso.net"),
            setOf("twitch.tv", "ttvnw.net", "jtvnw.net", "twitchcdn.net"),
            setOf("pinterest.com", "pinimg.com", "pin.it"),
            setOf("whatsapp.com", "whatsapp.net", "wa.me"),
            setOf("telegram.org", "t.me", "telegram.me", "telesco.pe", "tdesktop.com"),
            setOf("discord.com", "discordapp.com", "discord.gg", "discordapp.net", "discord.media"),
        )

        /**
         * Names browsers use for their own encrypted DNS ("Secure DNS"). Answering NXDOMAIN
         * for them makes the browser fall back to the phone's DNS (which we filter).
         */
        private val DOH_HOSTS = setOf(
            "dns.google", "dns.google.com", "dns64.dns.google", "cloudflare-dns.com", "one.one.one.one",
            "mozilla.cloudflare-dns.com", "chrome.cloudflare-dns.com", "security.cloudflare-dns.com",
            "family.cloudflare-dns.com", "dns.quad9.net", "dns9.quad9.net", "dns10.quad9.net", "dns11.quad9.net",
            "doh.opendns.com", "dns.opendns.com", "doh.cleanbrowsing.org", "dns.adguard.com", "dns.adguard-dns.com",
            "dns-family.adguard.com", "doh.dns.sb", "dns.nextdns.io", "doh.mullvad.net", "dns.mullvad.net",
            "use-application-dns.net",
        )

        private fun cleanDomain(raw: String): String =
            raw.lowercase().trim().removePrefix("http://").removePrefix("https://")
                .substringBefore('/').substringBefore('?').substringBefore(':').removePrefix("www.").trimEnd('.')

        private fun matches(h: String, d: String) = h == d || h.endsWith(".$d")

        /** Lower-case and drop separators, so "free-movies", "free movies" and "freemovies" all match "free movies". */
        private fun squash(t: String): String =
            t.lowercase().replace("%20", "").filter { it.isLetterOrDigit() }

        /** True if [text] (a host name, a typed address or a search) contains any blocked word. */
        fun hasBlockedWord(text: String, keywords: Set<String>): Boolean {
            if (keywords.isEmpty() || text.isBlank()) return false
            val t = squash(text)
            for (k in keywords) {
                val w = squash(k)
                if (w.length >= 3 && t.contains(w)) return true
            }
            return false
        }

        /**
         * What was typed / opened in a browser address bar: blocked if it is (or lies on) a
         * blocked site, or contains a blocked word anywhere in the address or search text.
         */
        fun addressBlocked(text: String, domains: Set<String>, keywords: Set<String>): Boolean {
            val raw = text.trim().lowercase()
            if (raw.isEmpty()) return false
            if (hasBlockedWord(raw, keywords)) return true
            val host = raw.removePrefix("http://").removePrefix("https://").substringBefore('/')
                .substringBefore('?').substringBefore('#').substringBefore(':')
            if (host.contains('.') && !host.contains(' ') && isBlocked(host, domains)) return true
            return false
        }

        /** True if [host] equals a blocked domain, is a subdomain of one, or belongs to the same site group. */
        fun isBlocked(host: String, domains: Set<String>, keywords: Set<String> = emptySet()): Boolean {
            val h = host.lowercase().trimEnd('.')
            if (h.isEmpty()) return false
            // Browser-level encrypted DNS would sidestep the filter entirely.
            if (DOH_HOSTS.any { matches(h, it) }) return domains.isNotEmpty() || keywords.isNotEmpty()
            if (hasBlockedWord(h, keywords)) return true
            for (raw in domains) {
                val d = cleanDomain(raw)
                if (d.isEmpty()) continue
                if (matches(h, d)) return true
                for (g in SITE_GROUPS) {
                    if (g.any { matches(d, it) } && g.any { matches(h, it) }) return true
                }
            }
            return false
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var pool: ExecutorService? = null

    @Volatile
    private var stopping = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            cancelWatchdog(this)
            shutdown(markInactive = true)
            stopSelf()
            return START_NOT_STICKY
        }
        if (isRunning) return START_STICKY

        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val builder = Builder()
            .setSession("Godfident website protection")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32) // only DNS to the fake server is captured
            .setBlocking(true)
        totalQueries = 0
        lastHost = ""
        lastError = ""
        val pfd = try {
            builder.establish()
        } catch (e: Exception) {
            lastError = "establish failed: ${e.message}"
            null
        }
        if (pfd == null) {
            if (lastError.isEmpty()) lastError = "Android refused to create the VPN (permission missing or revoked)"
            // VPN permission was not granted / revoked: do NOT claim protection.
            shutdown(markInactive = true)
            stopSelf()
            return START_NOT_STICKY
        }

        tun = pfd
        stopping = false
        isRunning = true
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, true).apply()
        scheduleWatchdog(this)
        pool = Executors.newCachedThreadPool()
        worker = Thread({ runLoop(pfd) }, "godfident-dns").also { it.start() }
        return START_STICKY
    }

    override fun onRevoke() {
        // The user turned the VPN off (or another VPN took over). Protection is
        // no longer running, but it is still WANTED: the app warns about it and
        // the watchdog / next launch switch it back on when Android allows it.
        shutdown(markInactive = false)
        stopSelf()
        super.onRevoke()
    }

    /** Swiping Godfident away from recents must not end protection. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val wanted = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ACTIVE, false)
        if (wanted) scheduleWatchdog(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        shutdown(markInactive = false)
        super.onDestroy()
    }

    private fun shutdown(markInactive: Boolean) {
        stopping = true
        isRunning = false
        try { worker?.interrupt() } catch (_: Exception) {}
        try { pool?.shutdownNow() } catch (_: Exception) {}
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        worker = null
        pool = null
        if (markInactive) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, false).apply()
        }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
    }

    // ───────────────────────── packet loop ─────────────────────────

    private fun runLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        while (!stopping && !Thread.currentThread().isInterrupted) {
            val len = try { input.read(buf) } catch (e: Exception) { lastError = "read: ${e.message}"; break }
            if (len <= 0) continue
            val packet = buf.copyOf(len)
            try {
                handlePacket(packet, output, prefs)
            } catch (_: Exception) {
                // malformed packet: drop it
            }
        }
    }

    private fun handlePacket(p: ByteArray, out: FileOutputStream, prefs: android.content.SharedPreferences) {
        if (p.size < 28) return
        val version = (p[0].toInt() shr 4) and 0xF
        if (version != 4) return
        val ihl = (p[0].toInt() and 0xF) * 4
        if (ihl < 20 || p.size < ihl + 8) return
        val proto = p[9].toInt() and 0xFF
        if (proto == 6) { rejectTcp(p, ihl, out); return }
        if (proto != 17) return

        val dstPort = ((p[ihl + 2].toInt() and 0xFF) shl 8) or (p[ihl + 3].toInt() and 0xFF)
        if (dstPort != 53) return

        val srcIp = p.copyOfRange(12, 16)
        val dstIp = p.copyOfRange(16, 20)
        val srcPort = ((p[ihl].toInt() and 0xFF) shl 8) or (p[ihl + 1].toInt() and 0xFF)
        val udpLen = ((p[ihl + 4].toInt() and 0xFF) shl 8) or (p[ihl + 5].toInt() and 0xFF)
        val payloadStart = ihl + 8
        val payloadEnd = minOf(p.size, ihl + udpLen)
        if (payloadEnd <= payloadStart + 12) return
        val dns = p.copyOfRange(payloadStart, payloadEnd)

        val parsed = parseQuestion(dns) ?: return
        totalQueries++
        lastHost = parsed.first
        val domains = prefs.getStringSet(KEY_DOMAINS, emptySet()) ?: emptySet()
        val keywords = prefs.getStringSet(KEY_KEYWORDS, emptySet()) ?: emptySet()

        if (isBlocked(parsed.first, domains, keywords)) {
            prefs.edit().putInt(KEY_BLOCKED_COUNT, prefs.getInt(KEY_BLOCKED_COUNT, 0) + 1).apply()
            // If a browser is on screen, close the page and send the person back to God's Word.
            try { FocusAccessibilityService.onBlockedLookup() } catch (_: Exception) {}
            val reply = buildNxDomain(dns, parsed.second)
            writeReply(out, dstIp, srcIp, srcPort, reply)
        } else {
            pool?.execute {
                // If no resolver answers, fail fast (SERVFAIL) instead of leaving the app hanging.
                val reply = forward(dns) ?: buildServFail(dns, parsed.second)
                writeReply(out, dstIp, srcIp, srcPort, reply)
            }
        }
    }

    /**
     * Answers any TCP attempt to the fake DNS address (e.g. Android's DNS-over-TLS
     * probe on port 853) with an immediate RST, so it fails fast and Android falls
     * back to plain DNS instead of hanging for several seconds.
     */
    private fun rejectTcp(p: ByteArray, ihl: Int, out: FileOutputStream) {
        if (p.size < ihl + 20) return
        val flags = p[ihl + 13].toInt() and 0xFF
        if (flags and 0x04 != 0) return // already a RST
        val srcIp = p.copyOfRange(12, 16)
        val dstIp = p.copyOfRange(16, 20)
        val srcPort0 = p[ihl].toInt() and 0xFF
        val srcPort1 = p[ihl + 1].toInt() and 0xFF
        val dstPort0 = p[ihl + 2].toInt() and 0xFF
        val dstPort1 = p[ihl + 3].toInt() and 0xFF
        var seq = 0L
        for (i in 4..7) seq = (seq shl 8) or (p[ihl + i].toLong() and 0xFF)
        val ack = (seq + (if (flags and 0x02 != 0) 1 else 0)) and 0xFFFFFFFFL
        val b = ByteArray(40)
        b[0] = 0x45; b[2] = 0; b[3] = 40; b[6] = 0x40; b[8] = 64; b[9] = 6
        System.arraycopy(dstIp, 0, b, 12, 4)
        System.arraycopy(srcIp, 0, b, 16, 4)
        val ck = ipChecksum(b, 20)
        b[10] = (ck shr 8).toByte(); b[11] = ck.toByte()
        b[20] = dstPort0.toByte(); b[21] = dstPort1.toByte()
        b[22] = srcPort0.toByte(); b[23] = srcPort1.toByte()
        // seq = 0
        b[28] = (ack shr 24).toByte(); b[29] = (ack shr 16).toByte(); b[30] = (ack shr 8).toByte(); b[31] = ack.toByte()
        b[32] = 0x50 // data offset 5 words
        b[33] = 0x14 // RST + ACK
        // TCP checksum over pseudo-header
        var sum = 0
        fun add(hi: Int, lo: Int) { sum += (hi and 0xFF shl 8) or (lo and 0xFF) }
        add(b[12].toInt(), b[13].toInt()); add(b[14].toInt(), b[15].toInt())
        add(b[16].toInt(), b[17].toInt()); add(b[18].toInt(), b[19].toInt())
        sum += 6; sum += 20
        var i = 20
        while (i < 40) { add(b[i].toInt(), b[i + 1].toInt()); i += 2 }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val tck = sum.inv() and 0xFFFF
        b[36] = (tck shr 8).toByte(); b[37] = tck.toByte()
        synchronized(this) { try { out.write(b) } catch (_: Exception) {} }
    }

    /** Returns (hostname, endOfQuestionOffset) or null. */
    private fun parseQuestion(dns: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < dns.size) {
            val l = dns[i].toInt() and 0xFF
            if (l == 0) {
                i++
                break
            }
            if (l and 0xC0 != 0) return null // compression not valid in a question
            i++
            if (i + l > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i, l, Charsets.ISO_8859_1))
            i += l
        }
        if (i + 4 > dns.size) return null
        return Pair(sb.toString(), i + 4)
    }

    private fun buildNxDomain(query: ByteArray, questionEnd: Int): ByteArray {
        val r = query.copyOf(questionEnd)
        r[2] = 0x81.toByte() // QR=1, RD=1
        r[3] = 0x83.toByte() // RA=1, RCODE=3 (NXDOMAIN)
        r[6] = 0; r[7] = 0   // ANCOUNT
        r[8] = 0; r[9] = 0   // NSCOUNT
        r[10] = 0; r[11] = 0 // ARCOUNT
        return r
    }

    private fun buildServFail(query: ByteArray, questionEnd: Int): ByteArray {
        val r = buildNxDomain(query, questionEnd)
        r[3] = 0x82.toByte() // RA=1, RCODE=2 (SERVFAIL)
        return r
    }

    private fun forward(query: ByteArray): ByteArray? {
        for (server in UPSTREAM_DNS) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                protect(socket) // bypass our own VPN
                socket.soTimeout = 4000
                val addr = InetAddress.getByName(server)
                socket.send(DatagramPacket(query, query.size, addr, 53))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                return buf.copyOf(resp.length)
            } catch (_: Exception) {
                // try next upstream
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        return null
    }

    @Synchronized
    private fun writeReply(out: FileOutputStream, srcIp: ByteArray, dstIp: ByteArray, dstPort: Int, payload: ByteArray) {
        val total = 20 + 8 + payload.size
        val b = ByteArray(total)
        b[0] = 0x45
        b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[6] = 0x40 // don't fragment
        b[8] = 64   // TTL
        b[9] = 17   // UDP
        System.arraycopy(srcIp, 0, b, 12, 4)
        System.arraycopy(dstIp, 0, b, 16, 4)
        val ck = ipChecksum(b, 20)
        b[10] = (ck shr 8).toByte(); b[11] = ck.toByte()
        // UDP header (checksum 0 is legal for IPv4)
        b[20] = 0; b[21] = 53
        b[22] = (dstPort shr 8).toByte(); b[23] = dstPort.toByte()
        val udpLen = 8 + payload.size
        b[24] = (udpLen shr 8).toByte(); b[25] = udpLen.toByte()
        System.arraycopy(payload, 0, b, 28, payload.size)
        try { out.write(b) } catch (_: Exception) {}
    }

    private fun ipChecksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    // ───────────────────────── notification ─────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Website protection", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Shown while Godfident is blocking websites"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val open = packageManager.getLaunchIntentForPackage(packageName)
        val pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Website protection is on")
            .setContentText("Godfident is blocking your protected websites.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }
}
